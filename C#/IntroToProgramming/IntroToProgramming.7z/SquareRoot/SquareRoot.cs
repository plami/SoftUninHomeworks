﻿using System;

    class SquareRoot
    {
        static void Main()
        {
            Console.WriteLine("The square root of 12345 is:");
            Console.WriteLine(Math.Sqrt(12345));
        }
    }

