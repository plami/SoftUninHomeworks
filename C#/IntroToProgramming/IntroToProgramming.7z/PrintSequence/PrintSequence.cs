﻿using System;

class PrintSequence
{
    static void Main()
    {
        for (int i = 2; i < 11; i++)
        {
            if (i % 2 == 1)
            {
                Console.WriteLine("-" +i);
            }
            else
            {
                Console.WriteLine(i);
            }
        }
    }
}
    
