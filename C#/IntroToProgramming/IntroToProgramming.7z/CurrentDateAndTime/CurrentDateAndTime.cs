﻿using System;

    class CurrentDateAndTime
    {
        static void Main()
        {
            Console.WriteLine("The current Date is:");
            Console.WriteLine(DateTime.Now.ToString("ddddd dd MMM, yyyy"));
            Console.WriteLine("The current time is:");
            Console.WriteLine(DateTime.Now.ToString("HH:mm:ss tt"));
        }
    }

